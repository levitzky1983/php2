-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jun 24, 2019 at 07:06 PM
-- Server version: 10.3.13-MariaDB
-- PHP Version: 7.1.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kitchen_sinks`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_user` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `login` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_user`, `name`, `login`, `pass`) VALUES
(1, 'admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id_order` int(11) NOT NULL,
  `client_name` varchar(50) NOT NULL,
  `client_phone` varchar(50) NOT NULL,
  `client_email` varchar(50) NOT NULL,
  `client_addres` varchar(100) NOT NULL,
  `id_sink` int(11) NOT NULL,
  `num` int(11) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `delivery` varchar(50) NOT NULL,
  `date` datetime NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id_order`, `client_name`, `client_phone`, `client_email`, `client_addres`, `id_sink`, `num`, `price`, `delivery`, `date`, `status`) VALUES
(12, '11', '453453', 'iv@m.ru', 'ert', 14, 1, '535', '', '2019-04-09 21:54:37', 'in_use'),
(13, '11', '453453', 'iv@m.ru', 'ert', 15, 1, '6456', '', '2019-04-09 21:54:37', 'post'),
(14, 'drydry', '345678', 'hfhfh', 'fghfghh', 14, 1, '535', '', '2019-04-10 17:30:39', 'new'),
(15, 'zzz', '222', 'zzz', 'zzz', 14, 1, '700', '', '2019-04-10 18:48:02', 'in_use'),
(16, 'zzz', '222', 'zzz', 'zzz', 16, 1, '555', '', '2019-04-10 18:48:02', 'new'),
(17, '11', '33333', 'iv@m.ru', 'fwdfw', 14, 1, '850', '', '2019-04-10 21:11:27', 'in_use'),
(18, '312', '312', '312', '3123', 19, 1, '222222', '', '2019-04-13 10:36:00', 'new'),
(19, '312', '312', '312', '3123', 23, 1, '333', '', '2019-04-13 10:36:00', 'new'),
(20, '312', '312', '312', '312', 23, 1, '333', '', '2019-04-13 10:36:59', 'new'),
(21, '11', '4234', 'iv@m.ru', '4234', 23, 1, '333', '', '2019-04-13 10:42:22', 'new'),
(22, '22', '42344', 'ter', '423423', 19, 3, '666666', '', '2019-04-13 10:50:16', 'new'),
(23, '22', '42344', 'ter', '423423', 19, 1, '222222', '', '2019-04-13 10:50:16', 'new'),
(24, '22', '42344', 'ter', '423423', 19, 1, '222222', '', '2019-04-13 10:50:16', 'new'),
(25, '22', '42344', 'ter', '423423', 19, 1, '222222', '', '2019-04-13 10:50:16', 'new'),
(26, '312', '312', '312', '312', 23, 3, '999', '', '2019-04-13 11:05:06', 'new'),
(27, '312', '312', '312', '312', 19, 1, '222222', '', '2019-04-13 11:05:06', 'new'),
(28, '312', '312', '312', '312', 19, 1, '222222', '', '2019-04-13 11:05:06', 'new'),
(29, '11', '312313123123123', '1@1.ru', '31231', 19, 20, '4444440', '', '2019-04-14 13:37:39', 'new'),
(30, '11', '312313123123123', '1@1.ru', '31231', 23, 20, '6660', '', '2019-04-14 13:37:40', 'new'),
(31, '11', '312313', 'iv@m.ru', 'wqeqe', 20, 10, '111110', 'Доставка курьером', '2019-04-14 19:11:19', 'new'),
(32, '11', 'dsafs', '', '321321', 19, 1, '222222', 'Самовывоз', '2019-04-14 19:12:31', 'new'),
(33, '22', '1111111111', 'iv@m.ru', 'asdsad', 19, 1, '222222', 'Самовывоз', '2019-04-14 19:41:00', 'new'),
(35, '3213', '3213213123213', '3123', '321313', 19, 2, '444444', 'Доставка курьером', '2019-04-14 20:00:41', 'new'),
(36, '3213', '3213213123213', '3123', '321313', 20, 1, '11111', 'Доставка курьером', '2019-04-14 20:00:41', 'new'),
(37, '423423', '433123131444', '4324234', '423423423', 19, 17, '3777774', 'Доставка курьером', '2019-04-14 20:58:31', 'new'),
(38, '423423', '433123131444', '4324234', '423423423', 20, 2, '22222', 'Доставка курьером', '2019-04-14 20:58:31', 'new');

-- --------------------------------------------------------

--
-- Table structure for table `sinks`
--

CREATE TABLE `sinks` (
  `id` int(11) NOT NULL,
  `article` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `form` varchar(20) NOT NULL,
  `manufacturer` varchar(50) NOT NULL,
  `color` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `info` text NOT NULL,
  `img` varchar(50) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `hit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sinks`
--

INSERT INTO `sinks` (`id`, `article`, `title`, `type`, `form`, `manufacturer`, `color`, `description`, `info`, `img`, `price`, `hit`) VALUES
(19, '', 'uraaaaaaaaa', 'steel', 'oval', '1', 'ZZZsasasas', 'qqqsasasas', 'wwwwasasasas', 'uran.jpg', '222222', 1),
(20, '', 'eeee', 'stone', 'oval', '2', 'vfdvdfvdfv', 'ffff', 'cccc', 'enot.jpg', '11111', 1),
(21, '', 'weqeqw', 'steel', 'oval', 'qqq', 'zzz', 'sdfsdf', 'fsdfsf', 'cat.jpg', '333', 0),
(22, '', 'fdsssdf', 'stone', 'square', 'vfdvdfvd', 'vvs', 'vsdvsv', 'vsdvs', 'dog.jpg', '4444', 0),
(23, '', 'vdsvsdvdsv', 'mix', '', '1', 'vsvs', 'vsv', 'vssdvsv', 'leopard.jpg', '333', 1),
(24, 'qqq22222', 'qqq12222', 'qqq32222', 'qqq42222', 'qqq52222', 'qqq622222', 'qqq722222', 'qqq822222', 'dog1.jpg', '4442222', 0),
(25, 'fgfgfgfg', '', 'steel', 'square', 'vdfgdfgdf', 'sdssggs', 'nxbxbfgngfn', 'gbgbfgbfgbfgbfg', 'uglovye-mojki-iz-nerzhavejki-dlya-kuhni-38.jpg', '2121', 1),
(26, 'RRRRRRRRRRR', '432423', 'stone', 'oval', '44gggff', 'dddd', 'dsdadasdasdasd', 'dsadadadasdadasd', 'chernaya-mojka-dlya-kuhni-42.jpg', '5020', 1),
(27, 'jjjjjjj', '6546546', 'stone', 'oval', 'AAA', 'qqq6', 'ggg', 'gggg', 'keramicheskaya-mojka-dlya-kuhni-37.jpg', '3333', 1),
(28, 'wwwwwwWW', '432423444', 'stone', 'square', 'fsdsdfsf', 'fsdfdsfsd', 'fsdfsdfsdf', 'fsdfsfsdfsfsf', 'ustanovka-mojki-na-kuhne-3.jpg', '3332', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id_order`);

--
-- Indexes for table `sinks`
--
ALTER TABLE `sinks`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `sinks`
--
ALTER TABLE `sinks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
